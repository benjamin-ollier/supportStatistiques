from encodings import utf_8
import win32com.client as client
from objet import Utilisateur
import cgi

def mail(nbTicketFerme,nbTicketCree,clientFav,tempsMoyen,nbIncident,nbDemande,nbTicketFermeLundi,nbTicketFermeMardi,nbTicketFermeMercredi,nbTicketFermeJeudi,nbTicketFermeVendredi,nbTicketCreeLundi,nbTicketCreeMardi,nbTicketCreeMercredi,nbTicketCreeJeudi,nbTicketCreeVendredi,nbTicketFermeLundiSd,nbTicketFermeMardiSd,nbTicketFermeMercrediSd,nbTicketFermeJeudiSd,nbTicketFermeVendrediSd,nbTicketCreeLundiSd,nbTicketCreeMardiSd,nbTicketCreeMercrediSd,nbTicketCreeJeudiSd,nbTicketCreeVendrediSd,nbTicketJanvier,nbTicketFevrier,nbTicketMars,nbTicketAvril,nbTicketMai,nbTicketJuin,nbTicketJuillet,nbTicketAout,nbTicketSeptembre,nbTicketOctobre,nbTicketNovembre,nbTicketDecembre,nbTicketCreeJanvier,nbTicketCreeFevrier,nbTicketCreeMars,nbTicketCreeAvril,nbTicketCreeMai,nbTicketCreeJuin,nbTicketCreeJuillet,nbTicketCreeAout,nbTicketCreeSeptembre,nbTicketCreeOctobre,nbTicketCreeNovembre,nbTicketCreeDecembre,o):
    report_file = open("html2.html")
    mess = report_file.read()


    outlook = client.Dispatch("Outlook.Application")
    message = outlook.CreateItem(0)
    message.Display()
    message.To = str(o)
    message.subject = 'Rapport opérateur'
    message.HTMLbody =mess.format(anbTicketFerme=nbTicketFerme,
    anbTicketCree=nbTicketCree,
    aclientFav=clientFav,
    atempsMoyen=tempsMoyen,
    anbIncident=nbIncident,
    anbDemande=nbDemande,

    anbTicketFermeLundi=nbTicketFermeLundi,
    anbTicketFermeMardi=nbTicketFermeMardi,
    anbTicketFermeMercredi=nbTicketFermeMercredi,
    anbTicketFermeJeudi=nbTicketFermeJeudi,
    anbTicketFermeVendredi=nbTicketFermeVendredi,

    anbTicketCreeLundi=nbTicketCreeLundi,
    anbTicketCreeMardi=nbTicketCreeMardi,
    anbTicketCreeMercredi=nbTicketCreeMercredi,
    anbTicketCreeJeudi=nbTicketCreeJeudi,
    anbTicketCreeVendredi=nbTicketCreeVendredi,

    anbTicketFermeLundiSd=nbTicketFermeLundiSd,
    anbTicketFermeMardiSd=nbTicketFermeMardiSd,
    anbTicketFermeMercrediSd=nbTicketFermeMercrediSd,
    anbTicketFermeJeudiSd=nbTicketFermeJeudiSd,
    anbTicketFermeVendrediSd=nbTicketFermeVendrediSd,

    anbTicketCreeLundiSd=nbTicketCreeLundiSd,
    anbTicketCreeMardiSd=nbTicketCreeMardiSd,
    anbTicketCreeMercrediSd=nbTicketCreeMercrediSd,
    anbTicketCreeJeudiSd=nbTicketCreeJeudiSd,
    anbTicketCreeVendrediSd=nbTicketCreeVendrediSd,

    anbTicketJanvier=nbTicketJanvier,
    anbTicketFevrier=nbTicketFevrier,
    anbTicketMars=nbTicketMars,
    anbTicketAvril=nbTicketAvril,
    anbTicketMai=nbTicketMai,
    anbTicketJuin=nbTicketJuin,
    anbTicketJuillet=nbTicketJuillet,
    anbTicketAout=nbTicketAout,
    anbTicketSeptembre=nbTicketSeptembre,
    anbTicketOctobre=nbTicketOctobre,
    anbTicketNovembre=nbTicketNovembre,
    anbTicketDecembre=nbTicketDecembre,

    anbTicketCreeJanvier=nbTicketCreeJanvier,
    anbTicketCreeFevrier=nbTicketCreeFevrier,
    anbTicketCreeMars=nbTicketCreeMars,
    anbTicketCreeAvril=nbTicketCreeAvril,
    anbTicketCreeMai=nbTicketCreeMai,
    anbTicketCreeJuin=nbTicketCreeJuin,
    anbTicketCreeJuillet=nbTicketCreeJuillet,
    anbTicketCreeAout=nbTicketCreeAout,
    anbTicketCreeSeptembre=nbTicketCreeSeptembre,
    anbTicketCreeOctobre=nbTicketCreeOctobre,
    anbTicketCreeNovembre=nbTicketCreeNovembre,
    anbTicketCreeDecembre=nbTicketCreeDecembre,

    aTotalNbTicketFerme=(nbTicketFermeLundi)+(nbTicketFermeMardi)+(nbTicketFermeMercredi)+(nbTicketFermeJeudi)+(nbTicketFermeVendredi),
    aTotalNbTicketCree=(nbTicketCreeLundi)+(nbTicketCreeMardi)+(nbTicketCreeMercredi)+(nbTicketCreeJeudi)+(nbTicketCreeVendredi),
    aTotalNbTicketFermeSd=(nbTicketFermeLundiSd)+(nbTicketFermeMardiSd)+(nbTicketFermeMercrediSd)+(nbTicketFermeJeudiSd)+(nbTicketFermeVendrediSd),
    aTotalNbTicketCreeSd=(nbTicketCreeLundiSd)+(nbTicketCreeMardiSd)+(nbTicketCreeMercrediSd)+(nbTicketCreeJeudiSd)+(nbTicketCreeVendrediSd),
    )

    message.SentOnBehalfOfName ='support.sam@monacodigital.mc'
    message.send
    print("mail sent successfully")