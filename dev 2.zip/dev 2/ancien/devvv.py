import requests
import json
import datetime


token='zWvsFY2ikbS2UhH_avdin6Kd42U'
currentYear=datetime.datetime.utcnow().strftime("%Y-01-01T08:00:00Z")

payload = json.dumps({
  "pageSize": 1000,
  "dateReference": "CREATION",
  "startDate": "{}".format(currentYear),
})

headerss = {'Authorization': 'Bearer {}'.format(token),
            'cache-control':'no-cache',
            'Content-Type': 'application/json'}

#json.loads
Liste = [{
  "id": 783,
    },
    {
    "id":456
    }]
print(type(Liste))

r = requests.get('https://monacodigital.cockpit-itsm.com/api/ticket/list/search',data=payload,headers=headerss)
#print(r.status_code)

texte=r.text
data = json.loads(texte)
#print(type(data))

print(r)

user = data["content"]
#print(user['id'])
#print(user['email'])

#print(data["content"][0])

num=0
#while num<1000:


    #print(data["content"][num]["id"])
    #if data["content"][0]["assignedUser"]["id"]== :
        #print('vrai')
    
    #else :
        #print('false')
        #num=num+1
idd=data["content"][0]["assignedUser"]["id"]
print(idd)
print(Liste.index(783))
Liste.index(["id"])