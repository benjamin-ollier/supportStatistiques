import requests
import json


#paramètres refresh token#############
headers = {'Authorization':'Basic YmVuZXR0ZXI6QlpuUnlPbUhzeVRtc1dPbw==','Content-Type':'application/x-www-form-urlencoded','cache-control':'no-cache'}
payload={'grant_type':'password',
'scope':'public-api',
'username':'apibollier',
'password':'9pBiLiUAfKDw'
}
url='https://monacodigital.cockpit-itsm.com/oauth/token'

#fonction refresh token#################
def refrechtoken():
    r = requests.post(url,data=payload,headers=headers)
    print(r.text)
    print(r.status_code)

    text = r.text
    data = json.loads(text)

    token=data["access_token"]
    print(token)
    return token
#######################################
refrechtoken()

headers = {'Authorization': 'Bearer {}'.format(token),
            'cache-control':'no-cache'}
payload={'teamid':'2'}

r = requests.get('https://monacodigital.cockpit-itsm.com/api/users/operators',data=payload,headers=headers)
print(r.text)
print(r.status_code)

if r.status == 200:
    

else:
    access_token=refresf
