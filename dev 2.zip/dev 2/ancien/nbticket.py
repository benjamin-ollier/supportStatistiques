import requests
import json
import datetime

#variables
currentYear=datetime.datetime.utcnow().strftime("%Y-01-01T08:00:00.Z")
nbPage=True

list = {
  "id": 783,
        "id": 4537,
        "type": "OPERATOR",
        "position": "Alternant",
        "email": "terence.dufrane@avangarde-mc.com",
        "phoneNumber": "",
        "mobileNumber": "",
        "firstName": "Terence",
        "lastName": "DUFRANE",
        "nbTotalTicket":0
},
{
        "id": 4534,
        "type": "OPERATOR",
        "position": "Alternant",
        "email": "benjamin.ollier@avangarde-mc.com",
        "firstName": "Benjamin",
        "lastName": "OLLIER",
        "nbTotalTicket":0
    }
Liste = json.loads(list)

#api
token='EoFHmDwUfrkAyZ4EuCEwdRKwgDg'
headers = {'Authorization': 'Bearer {}'.format(token),
            'cache-control':'no-cache'}
payloadd={
    "page": 0,
    "pageSize": 1000,
    "type":"REQUEST",
    "startDate": "{}".format(currentYear)
}


#page par page
while nbPage==True :
    r = requests.get('https://monacodigital.cockpit-itsm.com/api/ticket/list/search',data=payloadd,headers=headers)
    print(r.status_code)
    print(r.text)
    
    texte=r.text
    dataTicket = json.loads(texte)
    print(type(dataTicket))
  

    #élément par élément
    for i in dataTicket:
        user = dataTicket[0]
        print(user['id'])
        print(user['email'])
        print(user['type'])

    

    #nbTotalTicket=
    #ticketJourDernierCloturé=
    #nbTicketSemaineCloturé=

    if user['totalNumberOfPages']==user['page']:
        nbPage:False
    else :
        page: page+1
    print(page)
