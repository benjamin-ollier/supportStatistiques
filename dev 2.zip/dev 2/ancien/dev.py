import requests
import json
import datetime

token='LAufQJU8u__Cilsf0KwCwvWMxEs'
headers = {'Authorization': 'Bearer LAufQJU8u__Cilsf0KwCwvWMxEs',
            'cache-control':'no-cache'}

payload = json.dumps({
   "page": 0,
   "pageSize": 1000,
   "dateReference": "CREATION",
   "startDate": "2022-01-01T00:00:00.000Z",
   "status": "solved"
   })

r = requests.get('https://monacodigital.cockpit-itsm.com/api/ticket/list/search',data=payload,headers=headers)
print(r.status_code)
print(type(r))

text=r.text
data = json.loads(text)
print(type(data))

user = data["content"]

print(user)