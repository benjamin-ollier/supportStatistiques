from tkinter.font import BOLD
import xlsxwriter
from objet import Utilisateur
import win32com.client as win32
#import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Border, Side
import ntpath
from openpyxl import load_workbook
from openpyxl.styles import Font, Border, Side, GradientFill, Alignment


def writeExcel(dicObjet):
        for key in dicObjet:
         email1=str(dicObjet[str(key)].email)
         email=email1.replace(" ", "")
         
         wb = xlsxwriter.Workbook(r'C:\Users\benjamin.ollier\OneDrive - entreprise\Support Statistiques\{}.xlsx'.format(email))
         tab=wb.add_worksheet("tableau")

        #  #Titre avec nom
        #  text = str(dicObjet[str(key)].email)
        #  options = {
        #         'align': {
        #                 'vertical': 'middle',
        #                 'horizontal': 'center',
        #                 'text': 'center',
        #         'font': {
        #                 'bold': True,
        #                 'name': 'Arial',
        #                 'size': 12,}
        #                 },
        #         'border': {'color': 'black',
        #                    'width': 3}
        #  }

        #  bold = wb.add_format({'bold': True})
        #  border=wb.add_format({'color': 'black',
        #                    'width': 3})
        #  tab.write('F3',text,bold,border)


         ##TABLEAU 1
         my_list = ["Depuis le 1er janvier","Total"]
         titreGeneral = ['Nombre de tickets cloturés', 'Nombre de tickets créés', 'Client favori','Total incidents','Total demandes']
         donneeGeneral= [dicObjet[str(key)].nbTicketFerme,dicObjet[str(key)].nbTicketCree,dicObjet[str(key)].clientFav,dicObjet[str(key)].nbIncident,dicObjet[str(key)].nbDemande]
         tab.write_row(10, 1, my_list)
         tab.write_column(11, 1, titreGeneral)
         tab.write_column(11, 2, donneeGeneral)

         ##TABLEAU 2
         tabLigne1=['Semaine en cours','Lundi','Mardi','Mercredi','Jeudi','Vendredi']
         tabLigne2=['Nombre de tickets fermés',dicObjet[str(key)].nbTicketFermeLundi,dicObjet[str(key)].nbTicketFermeMardi,dicObjet[str(key)].nbTicketFermeMercredi,dicObjet[str(key)].nbTicketFermeJeudi,dicObjet[str(key)].nbTicketFermeVendredi]
         tabLigne3=['Nombre de tickets créés',dicObjet[str(key)].nbTicketCreeLundi,dicObjet[str(key)].nbTicketCreeMardi,dicObjet[str(key)].nbTicketCreeMercredi,dicObjet[str(key)].nbTicketCreeJeudi,dicObjet[str(key)].nbTicketCreeVendredi]
         tabLigne4=['Nombre de tickets fermés la semaine dernière',dicObjet[str(key)].nbTicketFermeLundiSd,dicObjet[str(key)].nbTicketFermeMardiSd,dicObjet[str(key)].nbTicketFermeMercrediSd,dicObjet[str(key)].nbTicketFermeJeudiSd,dicObjet[str(key)].nbTicketFermeVendrediSd]
         tabLigne5=['Nombre de tickets créés la semaine dernière',dicObjet[str(key)].nbTicketCreeLundiSd,dicObjet[str(key)].nbTicketCreeMardiSd,dicObjet[str(key)].nbTicketCreeMercrediSd,dicObjet[str(key)].nbTicketCreeJeudiSd,dicObjet[str(key)].nbTicketCreeVendrediSd]

         tab.write_row(19, 1, tabLigne1)
         tab.write_row(20, 1, tabLigne2)
         tab.write_row(21, 1, tabLigne3)
         tab.write_row(22, 1, tabLigne4)
         tab.write_row(23, 1, tabLigne5)

         ##TABLEAU 3
         tab1Ligne1=['Annuel','Janv','Fev','Mars','Avril','Mai','Juin','Juil','Aout','Sept','Oct','Nov','Dec']
         tab1Ligne2=['Nombre de tickets fermés',dicObjet[str(key)].nbTicketJanvier,dicObjet[str(key)].nbTicketFevrier,dicObjet[str(key)].nbTicketMars,dicObjet[str(key)].nbTicketAvril,dicObjet[str(key)].nbTicketMai,dicObjet[str(key)].nbTicketJuin,dicObjet[str(key)].nbTicketJuillet,dicObjet[str(key)].nbTicketAout,dicObjet[str(key)].nbTicketSeptembre,dicObjet[str(key)].nbTicketOctobre,dicObjet[str(key)].nbTicketNovembre,dicObjet[str(key)].nbTicketDecembre]
         tab1Ligne3=['Nombre de tickets créés',dicObjet[str(key)].nbTicketCreeJanvier,dicObjet[str(key)].nbTicketCreeFevrier,dicObjet[str(key)].nbTicketCreeMars,dicObjet[str(key)].nbTicketCreeAvril,dicObjet[str(key)].nbTicketCreeMai,dicObjet[str(key)].nbTicketCreeJuin,dicObjet[str(key)].nbTicketCreeJuillet,dicObjet[str(key)].nbTicketCreeAout,dicObjet[str(key)].nbTicketCreeSeptembre,dicObjet[str(key)].nbTicketCreeOctobre,dicObjet[str(key)].nbTicketCreeNovembre,dicObjet[str(key)].nbTicketCreeDecembre]
         
         tab.write_row(28, 1, tab1Ligne1)
         tab.write_row(29, 1, tab1Ligne2)
         tab.write_row(30, 1, tab1Ligne3)

         #Set size
         width= len("Nombre de tickets fermés la semaine dernière")
         tab.set_column(1, 1, width)

         wb.close()
         if email != "":
                 style(email)


def style(email):
 path=r'C:\Users\benjamin.ollier\OneDrive - entreprise\Support Statistiques\{}.xlsx'.format(email)
 wb2 = load_workbook(r'C:\Users\benjamin.ollier\OneDrive - entreprise\Support Statistiques\{}.xlsx'.format(email))
 ws4 = wb2['tableau']

 red="000000"
 thin = Side(border_style="thin", color=red)

 ws4["B11"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["C11"].border = Border(top=thin, left=thin, right=thin, bottom=thin)

 ws4["B20"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["C20"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["D20"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["E20"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["F20"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["G20"].border = Border(top=thin, left=thin, right=thin, bottom=thin)

 ws4["B29"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["C29"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["D29"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["E29"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["F29"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["G29"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["H29"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["I29"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["J29"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["K29"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["L29"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["M29"].border = Border(top=thin, left=thin, right=thin, bottom=thin)
 ws4["N29"].border = Border(top=thin, left=thin, right=thin, bottom=thin)



 ws4.merge_cells("C2:J4")
 top_left_cell = ws4["C2"]
 light_purple = "00CC99FF"
 green = "00008000"
 thin = Side(border_style="thin", color=light_purple)
 double = Side(border_style="double", color=green)
 top_left_cell.value = email

 #top_left_cell.fill = GradientFill(stop=("000000", "FFFFFF"))
 top_left_cell.font = Font(b=True, color="000000", size=16)
 top_left_cell.alignment = Alignment(horizontal="center",
                                        vertical="center")

 wb2.save(path)
