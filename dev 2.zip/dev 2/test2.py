from multiprocessing.sharedctypes import Value
from operator import truediv
import requests
import json
import datetime
import time
from objet import Utilisateur
from dateutil import parser
from datetime import datetime, timedelta,time
import mail
import operator
import fonctions

##Variables script
d=900
c=0
b=0
id=0
compteur=0
dicObjet = {}
dicObjet[str(4534)] = Utilisateur()
dicObjet[str(1121)] = Utilisateur()



#print("tdt",int(tempsDeTraitement))

#mail.mail(dicObjet[str(4534)].nbTicketFerme,dicObjet[str(4534)].nbTicketCree,dicObjet[str(4534)].clientFav,dicObjet[str(4534)].tempsMoyen,dicObjet[str(4534)].nbIncident,dicObjet[str(4534)].nbDemande,dicObjet[str(4534)].nbTicketFermeLundi,dicObjet[str(4534)].nbTicketFermeMardi,dicObjet[str(4534)].nbTicketFermeMercredi,dicObjet[str(4534)].nbTicketFermeJeudi,dicObjet[str(4534)].nbTicketFermeVendredi,dicObjet[str(4534)].nbTicketCreeLundi,dicObjet[str(4534)].nbTicketCreeMardi,dicObjet[str(4534)].nbTicketCreeMercredi,dicObjet[str(4534)].nbTicketCreeJeudi,dicObjet[str(4534)].nbTicketCreeVendredi,dicObjet[str(4534)].nbTicketJanvier,dicObjet[str(4534)].nbTicketFevrier,dicObjet[str(4534)].nbTicketMars,dicObjet[str(4534)].nbTicketAvril,dicObjet[str(4534)].nbTicketMai,dicObjet[str(4534)].nbTicketJuin,dicObjet[str(4534)].nbTicketJuillet,dicObjet[str(4534)].nbTicketAout,dicObjet[str(4534)].nbTicketSeptembre,dicObjet[str(4534)].nbTicketOctobre,dicObjet[str(4534)].nbTicketNovembre,dicObjet[str(4534)].nbTicketDecembre,dicObjet[str(4534)].nbTicketCreeJanvier,dicObjet[str(4534)].nbTicketCreeFevrier,dicObjet[str(4534)].nbTicketCreeMars,dicObjet[str(4534)].nbTicketCreeAvril,dicObjet[str(4534)].nbTicketCreeMai,dicObjet[str(4534)].nbTicketCreeJuin,dicObjet[str(4534)].nbTicketCreeJuillet,dicObjet[str(4534)].nbTicketCreeAout,dicObjet[str(4534)].nbTicketCreeSeptembre,dicObjet[str(4534)].nbTicketCreeOctobre,dicObjet[str(4534)].nbTicketCreeNovembre,dicObjet[str(4534)].nbTicketCreeDecembre)
token="sN6Xh_bRkjuxgPxf8P5AiHNCrMk"
dicoClientFav = dict()
nom="titi"
dicoClientFav={'titi': 2}
nom1="titO"

payloadd = json.dumps({
   })
headersss = {'Authorization': 'Bearer {}'.format(token),
              'cache-control': 'no-cache',
            'Content-Type': 'application/json'}
#json.loads
rr = requests.get('https://monacodigital.cockpit-itsm.com/api/users/operators',
                  data=payloadd, headers=headersss)

textee = rr.text
dataa = json.loads(textee)
print(type(dataa))




#for i in range(len(dataa)):
       #try :
             
       #except:
        #pass


for key in dicObjet:
 print(key)
 for i in range(len(dataa)):
       try :
             if str(dataa[i]["id"])==str(key):
                   dicObjet[str(key)].email=dataa[i]["email"]
       except:
             pass


print(dataa[1]["email"])
print("email: ",dicObjet[str(4534)].email)

