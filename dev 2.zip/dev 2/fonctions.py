import requests
import json
import datetime
from dateutil import parser
from objet import Utilisateur



def refreshToken():
    headers = {'Authorization':'Basic YmVuZXR0ZXI6QlpuUnlPbUhzeVRtc1dPbw==','Content-Type':'application/x-www-form-urlencoded','cache-control':'no-cache'}
    payload={'grant_type':'password',
    'scope':'public-api',
    'username':'apibollier',
    'password':'9pBiLiUAfKDw'
    }
    url='https://monacodigital.cockpit-itsm.com/oauth/token'

    r = requests.post(url,data=payload,headers=headers)
    #print(r.text)
    #print(r.status_code)

    text = r.text
    data = json.loads(text)

    token=data["access_token"]
    #print(token)
    return token


def maxPage(token):
 currentYear = datetime.datetime.utcnow().strftime("%Y-01-01T00:00:00.000Z")
 payload = json.dumps({
 "pageSize": 1000,
 "dateReference": "CREATION",
 "startDate": "{}".format(currentYear),
 "status": "solved",
 })
 headerss = {'Authorization': 'Bearer {}'.format(token),
 'cache-control': 'no-cache',
 'Content-Type': 'application/json'}

 r = requests.get('https://monacodigital.cockpit-itsm.com/api/ticket/list/search',
 data=payload, headers=headerss)

 texte = r.text
 data = json.loads(texte)
 maxPage = data["totalNumberOfPages"]

 # print("maxPage:",maxPage)
 return maxPage




def convertDate(i):
 #définition des variables par défaut
 an, mois, jour, heure, minute, seconde = 0, 0, 0, 0, 0, 0
 ordre = "ok"  # valeur par défaut de 'ordre'
  # continuer l'exécution en boucle si on tape autre chose que 'n' (voir ligne 43)
 n = int(i)  # convertit le nombre saisi en entier
 if (n>=60):
     minute=n//60 #calcule le nombre de minutes par division entière
     seconde=n%60 #calcule le nombre de secondes (le reste de la division entière)	
     if(minute>=60):
         heure=minute//60 #calcule le nombre d'heures
         minute=minute%60 #retourne le reste en minutes
         if(heure>=24):
             jour=heure//24 #calcule le nombre de jours
             heure=heure%24 #retourne le reste en heures
             if(jour>=30):
                 mois=jour//30 #calcule le nombre de mois
                 jour=jour%30 #retourne le reste en jours
                 if(mois>=12):
                     an=mois//12 #calcule le nombre d'années
                     mois=mois%12 #retourne le reste en mois
                 else:
                     an=0 #retourne 0 année si nombre de mois <12
             else:
                 mois=0 #retourne 0 mois si nombre de jours <30
         else:
             jour=0 #retourne 0 jour si nombre d'heures <24
     else:
         heure=0 #retourne 0 heure si nombre de minutes <60
 else:
     minute=0 #retourne 0 minute si nombre de secondes <60
     seconde=n #retourne le nombre de secondes
 print(an," année(s), ",mois," mois, ",jour," jour(s), ",heure," heure(s), ",minute," minute(s) et ",seconde," seconde(s).")


#retourne le temps en seconde d'un ticket
def calcul(date1,date2):
    date11=datetime.datetime.fromisoformat(date1.replace(".000Z", ""))
    date22=datetime.datetime.fromisoformat(date2.replace(".000Z", ""))

    date11=date11.timestamp()
    date22=date22.timestamp()

    tempsDeTrait=date22-date11
    return(tempsDeTrait)


def convertSecond(n):
 
    day = n // (24 * 3600)
 
    n = n % (24 * 3600)
    hour = n // 3600
 
    n %= 3600
    minutes = n // 60
 
    n %= 60
    seconds = n
     
    return "{t}j{tt}h".format(t=int(day),tt=int(hour))  #,int(minutes), "minutes",int(seconds), "seconds"
 

