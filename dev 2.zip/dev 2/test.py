from calendar import THURSDAY
import marshal
from unittest import TextTestResult
import requests
import json
import datetime
import fonctions
from objet import Utilisateur
from dateutil import parser
import time
import fonctionExcel
from openpyxl import Workbook
from openpyxl.styles import Border, Side
import ntpath
from openpyxl import load_workbook
import xlsxwriter


##Variables script
d = 900
c = 0
b = 0
i = 0
id = 0
compteur = 0
test = "t"
dicObjet={}

dicObjet[str(4534)] = Utilisateur()
dicObjet[str(11)] = Utilisateur()
dicObjet[str(4534)].email="ttt"
dicObjet[str(11)].email="tttt"

fonctionExcel.writeExcel(dicObjet)
