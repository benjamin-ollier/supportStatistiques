import marshal
import requests
import json
import datetime
import fonctions
from objet import Utilisateur
from dateutil import parser
import mail
import operator
#import fonctionExcel

##Variables script
d = 900
b = 0
id = 0
liste = []
compteur = 0
nb = 0
nb1 = 1
name = "a"
dicObjet = {}
test = "t"
dicMail = {"benjamin.ollier@avangarde-mc.com":4534}


##Enregistrement du Token
token = fonctions.refreshToken()
print("token:", token)

##Appel Fonction Maxpage
maxpage = fonctions.maxPage(token)
print("nombre max de pages :", maxpage)

#Démarrage du procéssus en semaine
todayDate=datetime.datetime.today()
if parser.parse(str(todayDate)).strftime('%A') == 'Saturday' or parser.parse(str(todayDate)).strftime('%A') == 'Sunday':
       print("JOUR DE WEEK-END")
else:
      ##Boucle d'incrementation sur la page json
      for i in range(maxpage):
            print("nouvelle page---------------------------------------------------------", i)

            date = datetime.date.today()
            currentYear = date.strftime("%Y-01-01T00:00:00.000Z") 
            payload = json.dumps({
            "page": i,
            "pageSize": 1000,
            "dateReference": "CREATION",
            "startDate": "{}".format(currentYear),
            })
            headerss = {'Authorization': 'Bearer {}'.format(token),
                        'cache-control': 'no-cache',
                        'Content-Type': 'application/json'}
            #json.loads
            r = requests.get('https://monacodigital.cockpit-itsm.com/api/ticket/list/search',
                              data=payload, headers=headerss)
                              
            texte = r.text
            data = json.loads(texte)
            #print(type(data))

            nbElementPremierePage = data["totalNumberOfElements"]
            #print("nb elements :",nbElementPremierePage)
            #compteur à 0 avant de se déplacer dans la page


            #Boucle sur chaque ticket de la page json
            b = 0
            while b < 1000:
                  try:
                        if "assignedUser" in data["content"][b]:
                              test = test
                  except IndexError:
                        print(IndexError)
                        break
                  except KeyError:
                        print(KeyError)
                        break



                  #AssignedUser présent
                  if "assignedUser" in data["content"][b]:
                        assignedId=data["content"][b]["assignedUser"]["id"]

                        #si l'objet n'existe pas:
                        if not str(data["content"][b]["assignedUser"]["id"]) in dicObjet:
                              #si ticket est fermé:
                              if data["content"][b]["status"]["category"]=="CLOSED" and not data["content"][b]["status"]["reference"]=="Canceled" and (data["content"][b]["status"]["reference"]=="Solved" or data["content"][b]["status"]["reference"]=="Completed") and not(data["content"][b]["status"]["category"]=="WORKING"):
                                     #print("if",data["content"][b]["assignedUser"]["id"])
                                     dicObjet[str(assignedId)] = Utilisateur()
                                     dicObjet[str(assignedId)].ajoutNbTicketFerme()

                                     #nbTicketJanvier
                                     if parser.parse(data["content"][b]["lastUpdate"]).month==1:
                                           dicObjet[str(assignedId)].nbTicketJanvier+=1
                                     if parser.parse(data["content"][b]["lastUpdate"]).month==2:
                                           dicObjet[str(assignedId)].nbTicketFevrier+=1
                                     if parser.parse(data["content"][b]["lastUpdate"]).month==3:
                                           dicObjet[str(assignedId)].nbTicketMars+=1
                                     if parser.parse(data["content"][b]["lastUpdate"]).month==4:
                                           dicObjet[str(assignedId)].nbTicketAvril+=1
                                     if parser.parse(data["content"][b]["lastUpdate"]).month==5:
                                           dicObjet[str(assignedId)].nbTicketMai+=1
                                     if parser.parse(data["content"][b]["lastUpdate"]).month==6:
                                           dicObjet[str(assignedId)].nbTicketJuin+=1
                                     if parser.parse(data["content"][b]["lastUpdate"]).month==7:
                                           dicObjet[str(assignedId)].nbTicketJuillet+=1
                                     if parser.parse(data["content"][b]["lastUpdate"]).month==8:
                                           dicObjet[str(assignedId)].nbTicketAout+=1
                                     if parser.parse(data["content"][b]["lastUpdate"]).month==9:
                                           dicObjet[str(assignedId)].nbTicketSeptembre+=1
                                     if parser.parse(data["content"][b]["lastUpdate"]).month==10:
                                           dicObjet[str(assignedId)].nbTicketOctobre+=1
                                     if parser.parse(data["content"][b]["lastUpdate"]).month==11:
                                           dicObjet[str(assignedId)].nbTicketNovembre+=1
                                     if parser.parse(data["content"][b]["lastUpdate"]).month==12:
                                           dicObjet[str(assignedId)].nbTicketDecembre+=1

                                     #Calcul le temps moyen total
                                     date1=data["content"][b]["creationDate"]
                                     date2=data["content"][b]["lastUpdate"]
                                     tempsDeTrait=fonctions.calcul(date1,date2)#recupere le temps en seconde d'un ticket
                                     dicObjet[str(assignedId)].tempsDeTraitement+=tempsDeTrait

                                     #Enregistrement des valeurs INCIDENT REQUEST
                                     if str(data["content"][b]["type"])=="INCIDENT":
                                           dicObjet[str(assignedId)].nbIncident+=1
                                     if str(data["content"][b]["type"])=="REQUEST":
                                           dicObjet[str(assignedId)].nbDemande+=1
 
                                     #Client Fav Ajout ou Creation
                                     nomOrg=data["content"][b]["organization"]["name"]
                                     if nomOrg not in dicObjet[str(assignedId)].dicoClientFav:
                                           dicObjet[str(assignedId)].dicoClientFav[nomOrg]=1
                                     else:
                                           dicObjet[str(assignedId)].dicoClientFav[nomOrg]+=1

                                     #Nombre de tickets fermés semaine actuelle
                                     dateTicket=data["content"][b]["lastUpdate"]
                                     today=datetime.datetime.today()
                                     if parser.parse(dateTicket).isocalendar()[1] == today.isocalendar()[1]:
                                           if parser.parse(dateTicket).strftime('%A') == 'Monday':
                                                 dicObjet[str(assignedId)].nbTicketFermeLundi+=1
                                           if parser.parse(dateTicket).strftime('%A') == 'Tuesday':
                                                 dicObjet[str(assignedId)].nbTicketFermeMardi+=1
                                           if parser.parse(dateTicket).strftime('%A') == 'Wednesday':
                                                 dicObjet[str(assignedId)].nbTicketFermeMercredi+=1
                                           if parser.parse(dateTicket).strftime('%A') == 'Thursday':
                                                 dicObjet[str(assignedId)].nbTicketFermeJeudi+=1
                                           if parser.parse(dateTicket).strftime('%A') == 'Friday':
                                                 dicObjet[str(assignedId)].nbTicketFermeVendredi+=1
                                     #Nb Ticket ferme semaine dernière
                                     todayy=today - datetime.timedelta(days=7)
                                     if todayy.isocalendar()[1] == parser.parse(dateTicket).isocalendar()[1]:
                                           if parser.parse(dateTicket).strftime('%A') == 'Monday':
                                                 dicObjet[str(assignedId)].nbTicketFermeLundiSd+=1
                                           if parser.parse(dateTicket).strftime('%A') == 'Tuesday':
                                                 dicObjet[str(assignedId)].nbTicketFermeMardiSd+=1
                                           if parser.parse(dateTicket).strftime('%A') == 'Wednesday':
                                                 dicObjet[str(assignedId)].nbTicketFermeMercrediSd+=1
                                           if parser.parse(dateTicket).strftime('%A') == 'Thursday':
                                                 dicObjet[str(assignedId)].nbTicketFermeJeudiSd+=1
                                           if parser.parse(dateTicket).strftime('%A') == 'Friday':
                                                 dicObjet[str(assignedId)].nbTicketFermeVendrediSd+=1

                              #nbTicketCree par mois
                              if "createdBy" in data["content"][b]:
                                    createdId=str(data["content"][b]["createdBy"]["id"])
                              else : 
                                    if "author" in data["content"][b]:
                                     createdId=str(data["content"][b]["author"]["id"])
                              try:
                                    #Si l'utilisateur est créé alors on enregistre dans l'objet
                                    if str(createdId) in dicObjet:
                                          if parser.parse(data["content"][b]["creationDate"]).month==1:
                                                dicObjet[str(createdId)].nbTicketCreeJanvier+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==2:
                                                dicObjet[str(createdId)].nbTicketCreeFevrier+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==3:
                                                dicObjet[str(createdId)].nbTicketCreeMars+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==4:
                                                dicObjet[str(createdId)].nbTicketCreeAvril+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==5:
                                                dicObjet[str(createdId)].nbTicketCreeMai+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==6:
                                                dicObjet[str(createdId)].nbTicketCreeJuin+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==7:
                                                dicObjet[str(createdId)].nbTicketCreeJuillet+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==8:
                                                dicObjet[str(createdId)].nbTicketCreeAout+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==9:
                                                dicObjet[str(createdId)].nbTicketCreeSeptembre+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==10:
                                                dicObjet[str(createdId)].nbTicketCreeOctobre+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==11:
                                                dicObjet[str(createdId)].nbTicketCreeNovembre+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==12:
                                                dicObjet[str(createdId)].nbTicketCreeDecembre+=1  
                                          dicObjet[str(createdId)].nbTicketCree+=1
                                          
                                          #Nombre de ticket créé semaine actuelle
                                          dateTicket=data["content"][b]["creationDate"]
                                          today=datetime.datetime.today()
                                          if parser.parse(dateTicket).isocalendar()[1] == today.isocalendar()[1]:
                                                if parser.parse(dateTicket).strftime('%A') == 'Monday':
                                                      dicObjet[str(createdId)].nbTicketCreeLundi+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Tuesday':
                                                      dicObjet[str(createdId)].nbTicketCreeMardi+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Wednesday':
                                                      dicObjet[str(createdId)].nbTicketCreeMercredi+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Thursday':
                                                      dicObjet[str(createdId)].nbTicketCreeJeudi+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Friday':
                                                      dicObjet[str(createdId)].nbTicketCreeVendredi+=1
                                          #Nb Ticket cree semaine dernière
                                          todayy=today - datetime.timedelta(days=7)
                                          if todayy.isocalendar()[1] == parser.parse(dateTicket).isocalendar()[1]:
                                                if parser.parse(dateTicket).strftime('%A') == 'Monday':
                                                      dicObjet[str(createdId)].nbTicketCreeLundiSd+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Tuesday':
                                                      dicObjet[str(createdId)].nbTicketCreeMardiSd+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Wednesday':
                                                      dicObjet[str(createdId)].nbTicketCreeMercrediSd+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Thursday':
                                                      dicObjet[str(createdId)].nbTicketCreeJeudiSd+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Friday':
                                                      dicObjet[str(createdId)].nbTicketCreeVendrediSd+=1
                              except:
                                     print("except")




                        #si l'utilisateur existe ####################################################################
                        else:
                              #Si le ticket est fermé
                              if data["content"][b]["status"]["category"]=="CLOSED" and not data["content"][b]["status"]["reference"]=="Canceled" and (data["content"][b]["status"]["reference"]=="Solved" or data["content"][b]["status"]["reference"]=="Completed") and not (data["content"][b]["status"]["category"]=="WORKING"):
                                    #nbTicketJanvier
                                    dicObjet[str(assignedId)].ajoutNbTicketFerme()
                                    if parser.parse(data["content"][b]["lastUpdate"]).month==1:
                                          dicObjet[str(assignedId)].nbTicketJanvier+=1
                                    if parser.parse(data["content"][b]["lastUpdate"]).month==2:
                                          dicObjet[str(assignedId)].nbTicketFevrier+=1
                                    if parser.parse(data["content"][b]["lastUpdate"]).month==3:
                                          dicObjet[str(assignedId)].nbTicketMars+=1
                                    if parser.parse(data["content"][b]["lastUpdate"]).month==4:
                                          dicObjet[str(assignedId)].nbTicketAvril+=1
                                    if parser.parse(data["content"][b]["lastUpdate"]).month==5:
                                          dicObjet[str(assignedId)].nbTicketMai+=1
                                    if parser.parse(data["content"][b]["lastUpdate"]).month==6:
                                          dicObjet[str(assignedId)].nbTicketJuin+=1
                                    if parser.parse(data["content"][b]["lastUpdate"]).month==7:
                                          dicObjet[str(assignedId)].nbTicketJuillet+=1
                                    if parser.parse(data["content"][b]["lastUpdate"]).month==8:
                                          dicObjet[str(assignedId)].nbTicketAout+=1
                                    if parser.parse(data["content"][b]["lastUpdate"]).month==9:
                                          dicObjet[str(assignedId)].nbTicketSeptembre+=1
                                    if parser.parse(data["content"][b]["lastUpdate"]).month==10:
                                          dicObjet[str(assignedId)].nbTicketOctobre+=1
                                    if parser.parse(data["content"][b]["lastUpdate"]).month==11:
                                          dicObjet[str(assignedId)].nbTicketNovembre+=1
                                    if parser.parse(data["content"][b]["lastUpdate"]).month==12:
                                          dicObjet[str(assignedId)].nbTicketDecembre+=1


                                    #Calcul le temps moyen total
                                    #date1=data["content"][b]["creationDate"]
                                    #date2=data["content"][b]["lastUpdate"]
                                    #tempsDeTrait=fonctions.calcul(date1,date2)#recupère le temps en seconde d'un ticket
                                    #dicObjet[str(assignedId)].tempsDeTraitement+=tempsDeTrait

                                    #Enregistrement des valeurs INCIDENT REQUEST
                                    if str(data["content"][b]["type"])=="INCIDENT":
                                                dicObjet[str(assignedId)].nbIncident+=1
                                    if str(data["content"][b]["type"])=="REQUEST":
                                                dicObjet[str(assignedId)].nbDemande+=1

                                    #Client Fav Ajout ou Creation
                                    nomOrg=data["content"][b]["organization"]["name"]
                                    if nomOrg not in dicObjet[str(assignedId)].dicoClientFav:
                                                dicObjet[str(assignedId)].dicoClientFav[nomOrg]=1
                                    else:
                                                dicObjet[str(assignedId)].dicoClientFav[nomOrg]+=1

                                    #Nombre de tickets fermés semaine actuelle
                                    dateTicket=data["content"][b]["actualResolutionDate"]
                                    dateTicketSd=data["content"][b]["actualResolutionDate"]
                                    today=datetime.datetime.today()
                                    if data["content"][b]["status"]["category"]=="CLOSED" and not data["content"][b]["status"]["reference"]=="Canceled" and (data["content"][b]["status"]["reference"]=="Solved" or data["content"][b]["status"]["reference"]=="Completed") and not (data["content"][b]["status"]["category"]=="WORKING"):
                                          if parser.parse(dateTicketSd).isocalendar()[1] == today.isocalendar()[1]:
                                                if str(data["content"][b]["assignedUser"]["id"])=="4534":
                                                             print("ticket F actuelle",data["content"][b]["id"])
                                                if parser.parse(dateTicketSd).strftime('%A') == 'Monday':
                                                      dicObjet[str(assignedId)].nbTicketFermeLundi+=1
                                                if parser.parse(dateTicketSd).strftime('%A') == 'Tuesday':
                                                      dicObjet[str(assignedId)].nbTicketFermeMardi+=1
                                                if parser.parse(dateTicketSd).strftime('%A') == 'Wednesday':
                                                      dicObjet[str(assignedId)].nbTicketFermeMercredi+=1
                                                if parser.parse(dateTicketSd).strftime('%A') == 'Thursday':
                                                      dicObjet[str(assignedId)].nbTicketFermeJeudi+=1
                                                if parser.parse(dateTicketSd).strftime('%A') == 'Friday':
                                                      dicObjet[str(assignedId)].nbTicketFermeVendredi+=1

                                          #Nb Ticket ferme semaine dernière
                                          todayy=today - datetime.timedelta(days=7)
                                          if (today.isocalendar()[1])-1 == parser.parse(dateTicketSd).isocalendar()[1]:
                                                if str(data["content"][b]["assignedUser"]["id"])=="4534":
                                                             print("Ticket F SD",data["content"][b]["id"])
                                                
                                                #if str(data["content"][b]["assignedUser"]["id"])==str(4534):
                                                       #print(data["content"][b]["assignedUser"]["id"])
                                                       #print("ticket:",data["content"][b]["id"])
                                                       #print("date:",(today.isocalendar()[1])-1," date ticket:",parser.parse(dateTicket).isocalendar()[1])
                                                if parser.parse(dateTicketSd).strftime('%A') == 'Monday':
                                                      dicObjet[str(assignedId)].nbTicketFermeLundiSd+=1
                                                if parser.parse(dateTicketSd).strftime('%A') == 'Tuesday':
                                                      dicObjet[str(assignedId)].nbTicketFermeMardiSd+=1
                                                if parser.parse(dateTicketSd).strftime('%A') == 'Wednesday':
                                                      dicObjet[str(assignedId)].nbTicketFermeMercrediSd+=1
                                                if parser.parse(dateTicketSd).strftime('%A') == 'Thursday':
                                                      dicObjet[str(assignedId)].nbTicketFermeJeudiSd+=1
                                                if parser.parse(dateTicketSd).strftime('%A') == 'Friday':
                                                      dicObjet[str(assignedId)].nbTicketFermeVendrediSd+=1

                              #nbTicketCréé
                              if "createdBy" in data["content"][b]:
                                    createdId=str(data["content"][b]["createdBy"]["id"])
                              else :
                                    if "author" in data["content"][b]:
                                          createdId=str(data["content"][b]["author"]["id"])
                              try:
                                    #Si l'utilisateur est créé alors on enregistre dans l'objet
                                    if str(createdId) in dicObjet:
                                          if parser.parse(data["content"][b]["creationDate"]).month==1:
                                                dicObjet[str(createdId)].nbTicketCreeJanvier+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==2:
                                                dicObjet[str(createdId)].nbTicketCreeFevrier+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==3:
                                                dicObjet[str(createdId)].nbTicketCreeMars+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==4:
                                                dicObjet[str(createdId)].nbTicketCreeAvril+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==5:
                                                dicObjet[str(createdId)].nbTicketCreeMai+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==6:
                                                dicObjet[str(createdId)].nbTicketCreeJuin+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==7:
                                                dicObjet[str(createdId)].nbTicketCreeJuillet+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==8:
                                                dicObjet[str(createdId)].nbTicketCreeAout+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==9:
                                                dicObjet[str(createdId)].nbTicketCreeSeptembre+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==10:
                                                dicObjet[str(createdId)].nbTicketCreeOctobre+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==11:
                                                dicObjet[str(createdId)].nbTicketCreeNovembre+=1
                                          if parser.parse(data["content"][b]["creationDate"]).month==12:
                                                dicObjet[str(createdId)].nbTicketCreeDecembre+=1  
                                          dicObjet[str(createdId)].nbTicketCree+=1
                                          
                                          #Ticket créé semaine actuelle
                                          dateTicket=data["content"][b]["creationDate"]
                                          today=datetime.datetime.today()
                                          if parser.parse(dateTicket).isocalendar()[1] == today.isocalendar()[1]:
                                                if parser.parse(dateTicket).strftime('%A') == 'Monday':
                                                      dicObjet[str(createdId)].nbTicketCreeLundi+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Tuesday':
                                                      dicObjet[str(createdId)].nbTicketCreeMardi+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Wednesday':
                                                      dicObjet[str(createdId)].nbTicketCreeMercredi+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Thursday':
                                                      dicObjet[str(createdId)].nbTicketCreeJeudi+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Friday':
                                                      dicObjet[str(createdId)].nbTicketCreeVendredi+=1
                                          #Ticket Crée semaine dernière
                                          todayy=today - datetime.timedelta(days=7)
                                          if (today.isocalendar()[1])-1 == parser.parse(dateTicket).isocalendar()[1]:
                                                if parser.parse(dateTicket).strftime('%A') == 'Monday':
                                                      dicObjet[str(createdId)].nbTicketCreeLundiSd+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Tuesday':
                                                      dicObjet[str(createdId)].nbTicketCreeMardiSd+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Wednesday':
                                                      dicObjet[str(createdId)].nbTicketCreeMercrediSd+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Thursday':
                                                      dicObjet[str(createdId)].nbTicketCreeJeudiSd+=1
                                                if parser.parse(dateTicket).strftime('%A') == 'Friday':
                                                      dicObjet[str(createdId)].nbTicketCreeVendrediSd+=1
                              except:
                                    print('except')
                  b=b+1



      #Traitement du temps moyen#######
      for i in dicObjet:
            variable=(dicObjet[i].tempsDeTraitement)/(dicObjet[i].nbTicketFerme)
            dicObjet[i].tempsMoyen=fonctions.convertSecond(variable)

            #Gestion du client Fav 
            try :
                  dicObjet[i].clientFav=str(max(dicObjet[i].dicoClientFav, key=lambda key: dicObjet[i].dicoClientFav[key]))
            except:
                  pass
      #################################



      #Extraire les mails ban ###########
      l=0
      ma_liste_ban=[]
      fichier = open("Ban.txt","r")
      for line in fichier:
            ma_liste_ban.append(line.strip())
      ##################################



      #Récuperer les emails des users 
      payloadd = json.dumps({
      })
      headersss = {'Authorization': 'Bearer {}'.format(token),
                  'cache-control': 'no-cache',
                  'Content-Type': 'application/json'}
      #json.loads
      rr = requests.get('https://monacodigital.cockpit-itsm.com/api/users/operators',
                        data=payloadd, headers=headersss)
      textee = rr.text
      dataa = json.loads(textee)
      for key in dicObjet:
       #print(key)
       for i in range(len(dataa)):
            try :
             if str(dataa[i]["id"])==str(key):
                  if "@monacodigital.mc" in dataa[i]["email"] or "avangarde-consulting.com" in dataa[i]["email"] or "@avangarde-mc.com" in dataa[i]["email"] or "monacoinformatiqueservice.mc" in dataa[i]["email"] or "monacodigital.mc" in dataa[i]["email"]:
                         dicObjet[str(key)].email=dataa[i]["email"]
            except:
                  pass
      ##################################


      #Enregistrement mail format Excel 
      #fonctionExcel.writeExcel(dicObjet)
      ###################################



      print("email de ben :",dicObjet[str(4534)].email)
      print("Liste d'email ban:",ma_liste_ban)

      print("ben ticket ferme",dicObjet[str(4534)].nbTicketFerme)
      print("ben ticket ferme ben",dicObjet[str(3736)].nbTicketFerme)
      print("ben ticket ferme florian",dicObjet[str(4980)].nbTicketFerme)
      print("ben ticket ferme Priscilla",dicObjet[str(3741)].nbTicketFerme)
      print("ben ticket ferme abdel",dicObjet[str(3576)].nbTicketFerme)
      print("ben ticket ferme seb",dicObjet[str(2958)].nbTicketFerme)

      print("ben tiket ferme Mars",dicObjet[str(4534)].nbTicketMars)
      print("nbTicketCree Avril",dicObjet[str(4534)].nbTicketCreeAvril)
      print("ben temps de traitement",dicObjet[str(4534)].tempsDeTraitement)
      print("ben ticket ferme",dicObjet[str(4534)].tempsMoyen)
      #print("clients : ",dicObjet[str(4534)].dicoClientFav)
      print("ben ticket ferme lundi",dicObjet[str(4534)].nbTicketFermeLundi)
      print("val ta race",dicObjet[str(3741)].nbTicketCreeMardi)     




      #Envoie des emails ###################
      #for cle, valeur in dicMail.items():
      #       if cle not in ma_liste_ban:
      #             mail.mail(dicObjet[str(valeur)].nbTicketFerme,dicObjet[str(valeur)].nbTicketCree,dicObjet[str(valeur)].clientFav,dicObjet[str(valeur)].tempsMoyen,dicObjet[str(valeur)].nbIncident,dicObjet[str(valeur)].nbDemande,dicObjet[str(valeur)].nbTicketFermeLundi,dicObjet[str(valeur)].nbTicketFermeMardi,dicObjet[str(valeur)].nbTicketFermeMercredi,dicObjet[str(valeur)].nbTicketFermeJeudi,dicObjet[str(valeur)].nbTicketFermeVendredi,dicObjet[str(valeur)].nbTicketCreeLundi,dicObjet[str(valeur)].nbTicketCreeMardi,dicObjet[str(valeur)].nbTicketCreeMercredi,dicObjet[str(valeur)].nbTicketCreeJeudi,dicObjet[str(valeur)].nbTicketCreeVendredi,dicObjet[str(valeur)].nbTicketFermeLundiSd,dicObjet[str(valeur)].nbTicketFermeMardiSd,dicObjet[str(valeur)].nbTicketFermeMercrediSd,dicObjet[str(valeur)].nbTicketFermeJeudiSd,dicObjet[str(valeur)].nbTicketFermeVendrediSd,dicObjet[str(valeur)].nbTicketCreeLundiSd,dicObjet[str(valeur)].nbTicketCreeMardiSd,dicObjet[str(valeur)].nbTicketCreeMercrediSd,dicObjet[str(valeur)].nbTicketCreeJeudiSd,dicObjet[str(valeur)].nbTicketCreeVendrediSd,dicObjet[str(valeur)].nbTicketJanvier,dicObjet[str(valeur)].nbTicketFevrier,dicObjet[str(valeur)].nbTicketMars,dicObjet[str(valeur)].nbTicketAvril,dicObjet[str(valeur)].nbTicketMai,dicObjet[str(valeur)].nbTicketJuin,dicObjet[str(valeur)].nbTicketJuillet,dicObjet[str(valeur)].nbTicketAout,dicObjet[str(valeur)].nbTicketSeptembre,dicObjet[str(valeur)].nbTicketOctobre,dicObjet[str(valeur)].nbTicketNovembre,dicObjet[str(valeur)].nbTicketDecembre,dicObjet[str(valeur)].nbTicketCreeJanvier,dicObjet[str(valeur)].nbTicketCreeFevrier,dicObjet[str(valeur)].nbTicketCreeMars,dicObjet[str(valeur)].nbTicketCreeAvril,dicObjet[str(valeur)].nbTicketCreeMai,dicObjet[str(valeur)].nbTicketCreeJuin,dicObjet[str(valeur)].nbTicketCreeJuillet,dicObjet[str(valeur)].nbTicketCreeAout,dicObjet[str(valeur)].nbTicketCreeSeptembre,dicObjet[str(valeur)].nbTicketCreeOctobre,dicObjet[str(valeur)].nbTicketCreeNovembre,dicObjet[str(valeur)].nbTicketCreeDecembre,cle)
      #       else:
      #             pass
      #######################################

      #Envoie mail pour chaque utilisateur(objet)
      for key in dicObjet:
            if dicObjet[str(key)].email not in ma_liste_ban:
                  if dicObjet[str(key)].email != "":
                   if str(key)==str(4534):
                         mail.mail(dicObjet[str(key)].nbTicketFerme,dicObjet[str(key)].nbTicketCree,dicObjet[str(key)].clientFav,dicObjet[str(key)].tempsMoyen,dicObjet[str(key)].nbIncident,dicObjet[str(key)].nbDemande,dicObjet[str(key)].nbTicketFermeLundi,dicObjet[str(key)].nbTicketFermeMardi,dicObjet[str(key)].nbTicketFermeMercredi,dicObjet[str(key)].nbTicketFermeJeudi,dicObjet[str(key)].nbTicketFermeVendredi,dicObjet[str(key)].nbTicketCreeLundi,dicObjet[str(key)].nbTicketCreeMardi,dicObjet[str(key)].nbTicketCreeMercredi,dicObjet[str(key)].nbTicketCreeJeudi,dicObjet[str(key)].nbTicketCreeVendredi,dicObjet[str(key)].nbTicketFermeLundiSd,dicObjet[str(key)].nbTicketFermeMardiSd,dicObjet[str(key)].nbTicketFermeMercrediSd,dicObjet[str(key)].nbTicketFermeJeudiSd,dicObjet[str(key)].nbTicketFermeVendrediSd,dicObjet[str(key)].nbTicketCreeLundiSd,dicObjet[str(key)].nbTicketCreeMardiSd,dicObjet[str(key)].nbTicketCreeMercrediSd,dicObjet[str(key)].nbTicketCreeJeudiSd,dicObjet[str(key)].nbTicketCreeVendrediSd,dicObjet[str(key)].nbTicketJanvier,dicObjet[str(key)].nbTicketFevrier,dicObjet[str(key)].nbTicketMars,dicObjet[str(key)].nbTicketAvril,dicObjet[str(key)].nbTicketMai,dicObjet[str(key)].nbTicketJuin,dicObjet[str(key)].nbTicketJuillet,dicObjet[str(key)].nbTicketAout,dicObjet[str(key)].nbTicketSeptembre,dicObjet[str(key)].nbTicketOctobre,dicObjet[str(key)].nbTicketNovembre,dicObjet[str(key)].nbTicketDecembre,dicObjet[str(key)].nbTicketCreeJanvier,dicObjet[str(key)].nbTicketCreeFevrier,dicObjet[str(key)].nbTicketCreeMars,dicObjet[str(key)].nbTicketCreeAvril,dicObjet[str(key)].nbTicketCreeMai,dicObjet[str(key)].nbTicketCreeJuin,dicObjet[str(key)].nbTicketCreeJuillet,dicObjet[str(key)].nbTicketCreeAout,dicObjet[str(key)].nbTicketCreeSeptembre,dicObjet[str(key)].nbTicketCreeOctobre,dicObjet[str(key)].nbTicketCreeNovembre,dicObjet[str(key)].nbTicketCreeDecembre,dicObjet[str(key)].email)  
