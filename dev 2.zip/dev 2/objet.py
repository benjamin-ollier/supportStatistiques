from ctypes import util
from re import U
import requests
import json
import datetime
from datetime import datetime


class Utilisateur:
     dicoClientFav = dict()
     clientFav=""
     tempsMoyen = 0
     list=[45]
     nbTicketFerme = 0
     nbTicketCree = 0

     nbTicketJanvier = 0
     nbTicketFevrier = 0
     nbTicketMars =0
     nbTicketAvril = 0
     nbTicketMai = 0
     nbTicketJuin = 0
     nbTicketJuillet = 0
     nbTicketAout = 0
     nbTicketSeptembre = 0
     nbTicketOctobre = 0
     nbTicketNovembre = 0
     nbTicketDecembre = 0

     nbTicketOuvertJanvier = 0
     nbTicketOuvertFevrier = 0
     nbTicketOuvertMars = 0
     nbTicketOuvertAvril = 0
     nbTicketOuvertMai = 0
     nbTicketOuvertJuin = 0
     nbTicketOuvertJuillet = 0
     nbTicketOuvertAout = 0
     nbTicketOuvertSeptembre = 0
     nbTicketOuvertOctobre = 0
     nbTicketOuvertNovembre = 0
     nbTicketOuvertDecembre = 0

     tempsDeTraitement=0

     nbIncident=0
     nbDemande=0

     nbTicketCreeJanvier = 0
     nbTicketCreeFevrier = 0
     nbTicketCreeMars = 0
     nbTicketCreeAvril = 0
     nbTicketCreeMai = 0
     nbTicketCreeJuin = 0
     nbTicketCreeJuillet = 0
     nbTicketCreeAout = 0
     nbTicketCreeSeptembre = 0
     nbTicketCreeOctobre = 0
     nbTicketCreeNovembre = 0
     nbTicketCreeDecembre = 0
     
     nbTicketFermeLundi=0
     nbTicketFermeMardi=0
     nbTicketFermeMercredi=0
     nbTicketFermeJeudi=0
     nbTicketFermeVendredi=0
     
     nbTicketCreeLundi=0
     nbTicketCreeMardi=0
     nbTicketCreeMercredi=0
     nbTicketCreeJeudi=0
     nbTicketCreeVendredi=0

     nbTicketFermeLundiSd=0
     nbTicketFermeMardiSd=0
     nbTicketFermeMercrediSd=0
     nbTicketFermeJeudiSd=0
     nbTicketFermeVendrediSd=0

     nbTicketCreeLundiSd=0
     nbTicketCreeMardiSd=0
     nbTicketCreeMercrediSd=0
     nbTicketCreeJeudiSd=0
     nbTicketCreeVendrediSd=0

     email=""
     
     def __init__(self):
         self.tempsMoyen=0
         self.tempsDeTraitement=0

         self.dicoClientFav = dict()
         self.clientFav=""

         self.nbTicketCree = 0
         self.nbTicketFerme = 0
         self.nbTicketJanvier = 0
         self.nbTicketFevrier = 0
         self.nbTicketMars =0
         self.nbTicketAvril = 0
         self.nbTicketMai = 0
         self.nbTicketJuin = 0
         self.nbTicketJuillet = 0
         self.nbTicketAout = 0
         self.nbTicketSeptembre = 0
         self.nbTicketOctobre = 0
         self.nbTicketNovembre = 0
         self.nbTicketDecembre = 0
         self.nbTicketOuvertJanvier = 0
         self.nbTicketOuvertFevrier = 0
         self.nbTicketOuvertMars = 0
         self.nbTicketOuvertAvril = 0
         self.nbTicketOuvertMai = 0
         self.nbTicketOuvertJuin = 0
         self.nbTicketOuvertJuillet = 0
         self.nbTicketOuvertAout = 0
         self.nbTicketOuvertSeptembre = 0
         self.nbTicketOuvertOctobre = 0
         self.nbTicketOuvertNovembre = 0
         self.nbTicketOuvertDecembre = 0

         self.nbIncident=0
         self.nbDemande=0

         self.nbTicketCreeJanvier = 0
         self.nbTicketCreeFevrier = 0
         self.nbTicketCreeMars = 0
         self.nbTicketCreeAvril = 0
         self.nbTicketCreeMai = 0
         self.nbTicketCreeJuin = 0
         self.nbTicketCreeJuillet = 0
         self.nbTicketCreeAout = 0
         self.nbTicketCreeSeptembre = 0
         self.nbTicketCreeOctobre = 0
         self.nbTicketCreeNovembre = 0
         self.nbTicketCreeDecembre = 0

         self.nbTicketFermeLundi=0
         self.nbTicketFermeMardi=0
         self.nbTicketFermeMercredi=0
         self.nbTicketFermeJeudi=0
         self.nbTicketFermeVendredi=0
     
         self.nbTicketCreeLundi=0
         self.nbTicketCreeMardi=0
         self.nbTicketCreeMercredi=0
         self.nbTicketCreeJeudi=0
         self.nbTicketCreeVendredi=0

         self.nbTicketFermeLundiSd=0
         self.nbTicketFermeMardiSd=0
         self.nbTicketFermeMercrediSd=0
         self.nbTicketFermeJeudiSd=0
         self.nbTicketFermeVendrediSd=0

         self.nbTicketCreeLundiSd=0
         self.nbTicketCreeMardiSd=0
         self.nbTicketCreeMercrediSd=0
         self.nbTicketCreeJeudiSd=0
         self.nbTicketCreeVendrediSd=0

         self.email=""

 
     def ajoutNbTicketFerme(self):
         self.nbTicketFerme+=1

     def afficheNbTicketFerme(self):
         print("nb ticket fermé {}".format(self.nbTicketFerme))

     def afficherNomObjet(self):
         print("nom objet :",self)

     def retourneTdt(self):
         ttt=self.tempsDeTraitement/2
         return ttt
